"use client";
import { useState, type FormEvent } from "react";
import CftFormShell, { Field, inputClass, optionClass } from "@/app/cft/_components/cft-form-shell";
import { PHASES, type Phase } from "@/lib/cft/fair-config";
const ENDPOINT = "/api/cft/post-survey";
const highlights=[{value:"canton_fair",label:"Visiting the Canton Fair"},{value:"products_suppliers",label:"Discovering products and suppliers"},{value:"guidance",label:"Guidance and support from the tour team"},{value:"business_connections",label:"Business discussions and connections"},{value:"other_guests",label:"Meeting other participants"},{value:"guangzhou_culture",label:"Guangzhou food and culture"},{value:"shenzhen_extension",label:"Shenzhen extension"},{value:"accommodation_transport",label:"Accommodation and transport"},{value:"other",label:"Other"}];
const outcomes=[{value:"specific_leads",label:"Found specific products or suppliers to follow up"},{value:"need_more_information",label:"Found opportunities but need more information"},{value:"researching",label:"Still researching and comparing options"},{value:"none_yet",label:"No specific sourcing outcome yet"}];
const stages=[{value:"ready_quote_sample",label:"Ready to request quotations or samples"},{value:"discussing_suppliers",label:"Discussing requirements with suppliers"},{value:"need_information",label:"Need more product or supplier information"},{value:"comparing",label:"Comparing suppliers or products"},{value:"future_research",label:"Researching for a future project"},{value:"no_current_plan",label:"No current purchasing plan"}];
const supports=[{value:"supplier_introduction",label:"Supplier introductions"},{value:"supplier_follow_up",label:"Supplier follow-up"},{value:"technical_information",label:"Product or technical information"},{value:"quotations",label:"Quotations"},{value:"samples",label:"Samples"},{value:"shipping_import",label:"Shipping or import guidance"},{value:"no_support",label:"No support needed"},{value:"other",label:"Other"}];
export default function SurveyForm({phase}:{phase:Phase}){
 const [respondentName,setRespondentName]=useState("");const [email,setEmail]=useState("");const [satisfaction,setSatisfaction]=useState("");const [selectedHighlights,setSelectedHighlights]=useState<string[]>([]);const [improvement,setImprovement]=useState("");const [categories,setCategories]=useState<string[]>([]);const [outcome,setOutcome]=useState("");const [purchaseStage,setPurchaseStage]=useState("");const [support,setSupport]=useState<string[]>([]);const [followUp,setFollowUp]=useState("");const [followUpDetails,setFollowUpDetails]=useState("");const [busy,setBusy]=useState(false);const [message,setMessage]=useState("");
 function toggle(list:string[],value:string,setter:(v:string[])=>void){setter(list.includes(value)?list.filter(x=>x!==value):[...list,value]);}
 async function submit(e:FormEvent){e.preventDefault();setMessage("");if(!respondentName.trim()||!satisfaction||!outcome||!purchaseStage||!followUp){setMessage("Please answer all required questions.");return;}if(email.trim()&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())){setMessage("Please enter a valid email address.");return;}setBusy(true);try{const res=await fetch(ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({source:`CFT_OCT2026_${phase.toUpperCase()}`,tourPhase:phase,respondentName:respondentName.trim(),email:email.trim()||null,satisfaction:Number(satisfaction),highlights:selectedHighlights,improvement:improvement.trim()||null,sourcingCategories:categories,outcome,purchaseStage,supportInterests:support,followUp,followUpDetails:followUpDetails.trim()||null})});const data=await res.json();if(!res.ok||data?.success!==true)throw new Error(data?.error||"Unable to submit. Please try again.");setMessage("Thank you! Your feedback has been submitted successfully.");}catch(err){setMessage(err instanceof Error?err.message:"Connection error. Please try again.");}finally{setBusy(false);}}
 return <CftFormShell phase={phase} title="Post-Tour Survey" description="Tell us about your experience and any sourcing opportunities you would like to follow up."><form onSubmit={submit} className="rounded-2xl border border-gray-200 bg-white p-5 sm:p-7">
 <Field label="Your name" required><input className={inputClass} autoComplete="name" value={respondentName} onChange={e=>setRespondentName(e.target.value)} placeholder="Enter your name" maxLength={120}/></Field>
 <Field label="Email (optional)"><input className={inputClass} type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Enter your email if you would like follow-up"/></Field>

<Field label="1. Overall, how satisfied were you with the tour?" required>
  <div className="space-y-2">
    {[
      { value: "5", label: "5 — Very satisfied" },
      { value: "4", label: "4" },
      { value: "3", label: "3" },
      { value: "2", label: "2" },
      { value: "1", label: "1 — Very dissatisfied" },
    ].map((x) => (
      <label key={x.value} className={optionClass}>
        <input
          className="mt-1 accent-emerald-800"
          type="radio"
          name="satisfaction"
          checked={satisfaction === x.value}
          onChange={() => setSatisfaction(x.value)}
        />
        <span>{x.label}</span>
      </label>
    ))}
  </div>
</Field> 

 <Field label="2. Which parts of the tour did you find most valuable? (optional)"><div className="space-y-2">{highlights.map(x=><label key={x.value} className={optionClass}><input className="mt-1 accent-emerald-800" type="checkbox" checked={selectedHighlights.includes(x.value)} onChange={()=>toggle(selectedHighlights,x.value,setSelectedHighlights)}/><span>{x.label}</span></label>)}</div></Field>
 <Field label="3. What is one thing we could improve? (optional)"><textarea className={inputClass} rows={3} maxLength={1000} value={improvement} onChange={e=>setImprovement(e.target.value)} placeholder="Optional feedback"/></Field>
 <Field label="4. Which product categories did you explore or want to follow up? (optional)"><div className="grid gap-2 sm:grid-cols-2">{PHASES[phase].categories.map(c=><label key={c.value} className={optionClass}><input className="mt-1 accent-emerald-800" type="checkbox" checked={categories.includes(c.value)} onChange={()=>toggle(categories,c.value,setCategories)}/><span>{c.label}</span></label>)}</div></Field>
 <Field label="5. Did you identify products or suppliers worth following up?" required><div className="space-y-2">{outcomes.map(x=><label key={x.value} className={optionClass}><input className="mt-1 accent-emerald-800" type="radio" name="outcome" checked={outcome===x.value} onChange={()=>setOutcome(x.value)}/><span>{x.label}</span></label>)}</div></Field>
 <Field label="6. Which best describes your current purchasing stage?" required><div className="space-y-2">{stages.map(x=><label key={x.value} className={optionClass}><input className="mt-1 accent-emerald-800" type="radio" name="purchaseStage" checked={purchaseStage===x.value} onChange={()=>setPurchaseStage(x.value)}/><span>{x.label}</span></label>)}</div></Field>
 <Field label="7. What follow-up support would be useful? (optional)"><div className="space-y-2">{supports.map(x=><label key={x.value} className={optionClass}><input className="mt-1 accent-emerald-800" type="checkbox" checked={support.includes(x.value)} onChange={()=>toggle(support,x.value,setSupport)}/><span>{x.label}</span></label>)}</div></Field>
 <Field label="8. Would you like CFT to contact you about your sourcing interests?" required><div className="flex gap-3">{[{value:"yes",label:"Yes"},{value:"no",label:"No"}].map(x=><label key={x.value} className={`${optionClass} flex-1`}><input className="mt-1 accent-emerald-800" type="radio" name="followUp" checked={followUp===x.value} onChange={()=>setFollowUp(x.value)}/><span>{x.label}</span></label>)}</div></Field>
 <Field label="9. Is there a specific product, supplier or next step you would like us to follow up? (optional)"><textarea className={inputClass} rows={3} maxLength={1000} value={followUpDetails} onChange={e=>setFollowUpDetails(e.target.value)} placeholder="Optional — tell us what you need"/></Field>
 {message&&<p role="status" className={`mb-4 rounded-lg p-3 text-sm ${message.startsWith("Thank you")?"bg-green-50 text-green-800":"bg-amber-50 text-amber-900"}`}>{message}</p>}
 <button disabled={busy} className="min-h-12 w-full rounded-lg bg-emerald-800 px-5 py-3 font-semibold text-white disabled:cursor-not-allowed disabled:opacity-60">{busy?"Submitting…":"Submit Post-Tour Survey"}</button>
 <p className="mt-3 text-xs leading-5 text-gray-500">Phase: {PHASES[phase].label}. Your selection is saved with this phase.</p>
 </form></CftFormShell>;
}
