import { supabase } from "@/lib/supabase"
import { notFound } from "next/navigation"
import Link from "next/link"
import PackageViewTracker from "@/components/PackageViewTracker"

import {
  calculatePackageAllocation,
} from "@/lib/package-allocation"

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}) 

{
  const { slug } = await params

  const { data: pkg } = await supabase
    .from("packages")
    .select(`
      name,
      slug,
      layout:layouts!packages_layout_id_fkey(
        slug,
        name
      )
    `)
    .eq("slug", slug)
    .single()

  if (!pkg) {
    return {
      title: "Package Not Found | MoveInReady",
    }
  }

  // ===== 统一 layout 结构 =====
  const layout = Array.isArray(pkg.layout)
    ? pkg.layout[0]
    : pkg.layout

  const layoutName =
    layout?.name || "New Zealand Home"

  const layoutSlug =
    layout?.slug || "layout"

  const packageType =
    pkg.name?.toLowerCase() || "package"

  return {
    title: `${pkg.name} Furniture Package | ${layoutName} | MoveInReady`,

    description:
      `${pkg.name} furniture package designed for ${layoutName}. ` +
      `Explore move-in ready furniture solutions for modern New Zealand homes.`,

    keywords: [
      "move in ready furniture",
      "furniture package NZ",
      "new home furniture package",
      "fully furnished home",
      `${layoutName} furniture package`,
      `${pkg.name} package`,
      "Christchurch furniture package",
      "New Zealand home furniture",
    ],

    openGraph: {
      title: `${pkg.name} Package | ${layoutName}`,

      description:
        `Complete furniture package for ${layoutName}. ` +
        `Designed for modern move-in ready living.`,

      images: [
        `/packages/${layoutSlug}_${packageType}_overview.jpg`,
      ],
    },
  }
}

export default async function PackagePage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>
  searchParams: Promise<{
    src?: string
  }>
}) 

{
  const { slug } = await params

  const { src = "website" } = await searchParams

  // ===== Package =====
const { data: pkg } = await supabase
  .from("packages")
  .select(`
    id,
    name,
    slug,
    display_price,
    layout_id,
    layout:layouts!packages_layout_id_fkey(
      slug,
      name,
      location,
      bedrooms,
      bathrooms,
      garage,
      floor_size,
      land_size
    )
  `)
    .eq("slug", slug)
    .single()

  if (!pkg) return notFound()

  // ===== 统一 layout 结构 =====
  const layout = Array.isArray(pkg.layout)
    ? pkg.layout[0]
    : pkg.layout

  if (!layout) return notFound()

const { data: openings } =
  await supabase
    .from("layout_openings")
    .select(`
      id,
      width_mm,
      height_mm,
      opening_code,
      room_name
    `)
    .eq(
      "layout_id",
      pkg.layout_id
    )

  const { data: sunshineProducts } =
  await supabase
    .from("package_opening_products")
    .select(`
      id,
      package_id,
      opening_id,
      quantity,

      product:products(
        id,
        sku_code,
        display_name_en,
        display_description_en,
        image_url
      ),

      variant:variants(
        id,
        price_rmb,
        size_label,
        config,
        display_config_en,
        display_note_en,
        width_mm,
        length_mm,
        height_mm
      )
    `)
    .eq(
      "package_id",
      pkg.id
    )

const openingMap:
Record<string, any> = {}

openings?.forEach(
  (o) => {

    openingMap[o.id] = o

  }
)

  const layoutSlug = layout.slug

  const packageType =
    pkg.name?.toLowerCase()

  // ===== 同layout packages =====
  const { data: allPackages } = await supabase
    .from("packages")
    .select("name, slug")
    .eq("layout_id", pkg.layout_id)

  // ===== Rooms =====
  const { data: rooms } = await supabase
    .from("package_rooms")
    .select(`
      id,
      name,
      sort_order
    `)
    .eq("package_id", pkg.id)
    .order("sort_order")

  // ===== Items =====
  const { data: items } = await supabase
    .from("package_items")
    .select(`
      id,
      package_room_id,
      item_type:item_types(name),
products:package_item_products(

  id,
  quantity,
  opening_id,

  product:products(
    id,
    sku_code,
    display_name_en,
    display_description_en,
    image_url
  ),

  variant:variants(
    id,
    price_rmb,
    size_label,
    config,
    display_config_en,
    display_note_en,
    width_mm,
    length_mm,
    height_mm
  )

)
    `)
    .in("package_room_id", rooms?.map(r => r.id) || [])

  const grouped: Record<string, any[]> = {}

const allocationRows: any[] = []

items?.forEach(
  (item: any) => {

    item.products?.forEach(
      (p: any) => {

        allocationRows.push({

          pip_id:
            p.id,

            opening_id:
  p.opening_id,

          sku_code:
            p.product?.sku_code || "",

          quantity:
            p.quantity || 0,

          exw_price_rmb:
            p.variant?.price_rmb || 0,

          width_mm:
            p.opening_id
              ? openingMap[
                  p.opening_id
                ]?.width_mm
              : null,

          height_mm:
            p.opening_id
              ? openingMap[
                  p.opening_id
                ]?.height_mm
              : null,

        })

      }
    )

  }
)

sunshineProducts?.forEach(
  (p: any) => {

    allocationRows.push({

      pip_id:
        p.id,

      opening_id:
        p.opening_id,

      sku_code:
        p.product?.sku_code || "",

      quantity:
        p.quantity || 0,

      exw_price_rmb:
        p.variant?.price_rmb || 0,

      width_mm:
        p.opening_id
          ? openingMap[
              p.opening_id
            ]?.width_mm
          : null,

      height_mm:
        p.opening_id
          ? openingMap[
              p.opening_id
            ]?.height_mm
          : null,

    })

  }
)

const allocation =
  calculatePackageAllocation(
    allocationRows,
    pkg.display_price || 0
  )

const valueMap:
Record<string, number> = {}

allocation.rows.forEach(
  (row: any) => {

    valueMap[
      row.pip_id
    ] =
      row.included_value

  }
)

items?.forEach((i: any) => {

  if (!i.products?.length) return

  if (!grouped[i.package_room_id]) {
    grouped[i.package_room_id] = []
  }

  grouped[i.package_room_id].push(i)
})

  sunshineProducts?.forEach(
  (p: any) => {

    const opening =
      openingMap[p.opening_id]

    if (!opening) return

    const room =
      rooms?.find(
        (r: any) =>
          r.name === opening.room_name
      )

    if (!room) return

    if (!grouped[room.id]) {
      grouped[room.id] = []
    }

    grouped[room.id].push({

      id:
        `sunshine-${p.id}`,

      package_room_id:
        room.id,

item_type: {
  name:
    p.product?.sku_code?.startsWith("SUN-CUR-")
      ? "curtain"
      : p.product?.sku_code?.startsWith("SUN-TRK-")
        ? "track"
        : p.product?.sku_code?.startsWith("SUN-BLD-")
          ? "blind"
          : "sunshine",
},

      products: [
        {
          id:
            p.id,

          opening_id:
            p.opening_id,

          quantity:
            p.quantity,

          product:
            p.product,

          variant:
            p.variant,
        },
      ],

    })

  }
)

const summary: Record<
  string,
  number
> = {}

Object.values(
  grouped
).forEach(
  (roomItems: any[]) => {

    roomItems.forEach(
      (item: any) => {

        const itemName =
          item.item_type?.name

        if (!itemName) return

        const qty =
          item.products?.reduce(
            (
              total: number,
              p: any
            ) =>
              total +
              (
                p.quantity || 0
              ),
            0
          ) || 0

        summary[itemName] =
          (
            summary[itemName] || 0
          ) + qty

      }
    )

  }
)

return (
  <div className="max-w-6xl mx-auto px-6 py-10 space-y-12">

    <PackageViewTracker
      packageId={pkg.id}
      leadSource={src}
    />

{/* ===== Package Hero ===== */}

<div className="space-y-8 text-center">

  <div className="space-y-3">

    <div className="text-sm uppercase tracking-wide text-gray-400">
      Move-In Ready Furniture Package
    </div>

    <h1 className="text-3xl md:text-4xl font-semibold leading-tight">
      {pkg.name} Package
    </h1>

    {pkg.display_price && (
      <div className="text-xl text-gray-600">
        Fully furnished from ${pkg.display_price}
      </div>
    )}

    <div className="text-gray-500 max-w-2xl mx-auto leading-relaxed">
      A complete furniture solution designed around the{" "}
      {layout.name} floor plan, helping you create a
      comfortable, coordinated home ready to move in.
    </div>

  </div>

  {/* ===== Benefits ===== */}

  <div className="max-w-4xl mx-auto border rounded-2xl p-6 bg-gray-50 text-left">

    <h2 className="text-2xl font-semibold mb-5 text-center">
      Why Choose This Package
    </h2>

    <div className="grid md:grid-cols-2 gap-4 text-gray-700">

      <div>
        ✓ Designed around your home layout
      </div>

      <div>
        ✓ Complete living, dining and bedroom solution
      </div>

      <div>
        ✓ Coordinated furniture selection
      </div>

      <div>
        ✓ Delivery and installation included
      </div>

    </div>

  </div>

</div>

{/* ===== What's Included ===== */}

<div
  className="
    border
    rounded-2xl
    p-5
    max-w-4xl
    mx-auto
  "
>

  <div className="font-semibold text-lg mb-4 text-center">
    What's Included
  </div>

  <div className="flex flex-wrap gap-3 justify-center">

    {Object.entries(summary).map(
      ([name, qty]) => (

        <div
          key={name}
          className="
            px-4
            py-2
            border
            rounded-full
            text-sm
          "
        >
          {qty}
          {" × "}
          {name}
        </div>

      )
    )}

  </div>

</div>

{/* ===== Email CTA ===== */}

<div className="border rounded-2xl p-8 max-w-2xl mx-auto text-center">

  <h2 className="text-2xl font-semibold">
    Want the Complete Package?
  </h2>

  <p className="text-gray-600 mt-3">
    Enter your email and we'll send you the complete
    package PDF — FREE.
  </p >

  <form
    action="/api/package-request"
    method="POST"
    className="mt-6 space-y-3"
  >

    <input
      type="hidden"
      name="package_id"
      value={pkg.id}
    />

    <input
      type="hidden"
      name="lead_source"
      value={src}
    />

    <input
      type="email"
      name="email"
      required
      placeholder="Your email address"
      className="w-full border rounded-lg px-4 py-3"
    />

    <button
      type="submit"
      className="
        w-full
        bg-black
        text-white
        py-3
        rounded-lg
        hover:opacity-90
        transition
      "
    >
      Email Me This Package
    </button>

  </form>

</div>

      {/* ===== Package切换 ===== */}
      <div className="flex gap-3 flex-wrap justify-center">

        {allPackages?.map((p: any) => (
          <Link
            key={p.slug}
            href={`/packages/${p.slug}`}
            className={`px-4 py-2 border rounded-lg text-sm transition ${
              p.slug === slug
                ? "bg-black text-white border-black"
                : "hover:bg-gray-50"
            }`}
            prefetch={false}
          >
            {p.name}
          </Link>
        ))}

      </div>

{/* ===== Rooms ===== */}

<div className="space-y-14">

        {rooms?.map((room: any) => (
<div
  id={`room-${room.id}`}
  key={room.id}
  className="space-y-5"
>

            {/* Room Title */}
            <div className="border-b pb-2">
              <h2 className="text-2xl font-semibold">
                {room.name}
              </h2>
            </div>

            {/* Products */}
            <div className="grid md:grid-cols-2 gap-4">

              {grouped[room.id]?.map((item: any) => (
                <div
                  key={item.id}
                  className="border rounded-2xl p-4 space-y-3 hover:shadow-sm transition"
                >

<div className="flex uppercase justify-between items-center">

  <div className="text-sm text-gray-500">
    {item.item_type?.name}
  </div>

  <div className="text-xs text-gray-400">

    Qty: {

      item.products?.reduce(
        (
          total: number,
          p: any
        ) =>
          total +
          (
            p.quantity || 0
          ),
        0
      )

    }

  </div>

</div>

                  {item.products?.map((p: any, idx: number) => (
                    <Link
                      key={idx}
                      href={`/products/${p.product?.id}`}
                      className="flex items-center gap-3 hover:bg-gray-50 p-2 rounded-lg transition"
                      prefetch={false}
                    >

                      {p.product?.image_url && (
                        <img
                          src={p.product.image_url}
                          className="w-16 h-16 object-contain"
                          loading="lazy"
                        />
                      )}

                      <div className="text-sm flex-1">

                        <div className="font-medium">
                          {p.product?.display_name_en}
                        </div>

<div className="text-green-700 font-medium">

  Included Value

  {" "}

  $

  {

    valueMap[
      p.id
    ]?.toLocaleString()

  }

</div>
 
{/* ===== Variant ===== */}

{(
  p.variant?.display_config_en ||
  p.variant?.config ||
  p.variant?.size_label ||
  p.variant?.width_mm ||
  p.variant?.length_mm ||
  p.variant?.height_mm
) && (

  <div className="mt-2 space-y-1">

    {(p.variant?.display_config_en ||
      p.variant?.config) && (

      <div className="text-sm font-medium text-gray-700">

        {p.variant?.display_config_en ||
          p.variant?.config}

      </div>

    )}

{p.product?.sku_code?.startsWith("SUN-")
  ? (

      p.opening_id &&
      openingMap[
        p.opening_id
      ] && (

<div className="text-sm text-gray-500">

  Opening

  {" "}

  {
    openingMap[
      p.opening_id
    ]?.opening_code
  }

  {" · "}

  {
    openingMap[
      p.opening_id
    ]?.width_mm
  }

  ×

  {
    openingMap[
      p.opening_id
    ]?.height_mm
  }

  mm

</div>

      )

    )
  : (

      p.variant?.size_label && (

        <div className="text-sm text-gray-500">

          Size: {p.variant.size_label}

        </div>

      )

    )
}

    {p.variant?.display_note_en && (

      <div className="text-xs text-gray-500">

        {p.variant.display_note_en}

      </div>

    )}

    {(
      p.variant?.width_mm ||
      p.variant?.length_mm ||
      p.variant?.height_mm
    ) && (

      <div className="text-xs text-gray-500">

        Dimensions:{" "}

        {p.variant?.width_mm || "-"}

        ×

        {p.variant?.length_mm || "-"}

        ×

        {p.variant?.height_mm || "-"}

        mm

      </div>

    )}

  </div>

)}


                      </div>

                      <div className="text-sm text-gray-500">
                        x{p.quantity}
                      </div>

                    </Link>
                  ))}

                </div>
              ))}

            </div>

          </div>
        ))}

      </div>

      {/* ===== SEO Content ===== */}
      <div className="border-t pt-10">

        <div className="max-w-3xl space-y-4 text-gray-600 leading-relaxed">

          <h2 className="text-2xl font-semibold text-black">
            Move-In Ready Furniture Packages in New Zealand
          </h2>

          <p>
            MoveInReady provides complete furniture packages
            designed for real New Zealand home layouts.
            Each package is curated to simplify the move-in
            process and help homeowners furnish their homes
            faster and more efficiently.
          </p >

          <p>
            The {pkg.name} Package for {layout.name}
            includes coordinated furniture selections across
            living, dining and bedroom spaces, balancing
            comfort, functionality and contemporary aesthetics.
          </p >

        </div>

      </div>

{/* ===== Email CTA ===== */}

<div className="border rounded-2xl p-8 max-w-2xl mx-auto text-center">

  <h2 className="text-2xl font-semibold">
    Want the Complete Package?
  </h2>

  <p className="text-gray-600 mt-3">
    Enter your email and we'll send you the complete
    package PDF — FREE.
  </p >

  <form
    action="/api/package-request"
    method="POST"
    className="mt-6 space-y-3"
  >

    <input
      type="hidden"
      name="package_id"
      value={pkg.id}
    />

    <input
      type="hidden"
      name="lead_source"
      value={src}
    />

    <input
      type="email"
      name="email"
      required
      placeholder="Your email address"
      className="w-full border rounded-lg px-4 py-3"
    />

    <button
      type="submit"
      className="
        w-full
        bg-black
        text-white
        py-3
        rounded-lg
        hover:opacity-90
        transition
      "
    >
      Email Me This Package
    </button>

  </form>

</div>

    </div>
  )
}